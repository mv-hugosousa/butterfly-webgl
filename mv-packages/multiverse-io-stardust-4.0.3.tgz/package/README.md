# stardust

[![Release Github Package](https://github.com/Multiverse-io/stardust/actions/workflows/release-package.yml/badge.svg)](https://github.com/Multiverse-io/stardust/actions/workflows/release-package.yml)

Design tokens for the Multiverse Stardust design system, helping maintain consistency and scalability in our design system.

## Related libraries

- 🐣 **Elixir and Phoenix** - Looking to install Stardust into a Phoenix application? [See the `stardust_phoenix` repo for details](https://github.com/Multiverse-io/stardust_phoenix)
- ⚛️ **TypeScript and React** - Looking to install Stardust into a React application? [See the `stardust-react` repo for details](https://github.com/Multiverse-io/stardust-react)

## Contributing

Please read the [contributing guide](/CONTRIBUTING.md).

## Installation

You will need a Github Access Token for your user for your local package manager to be allowed access to the Multiverse Github package registry.

### Setting up the package registry

This token needs to be added to the following files:

~/.npmrc

```
//npm.pkg.github.com/:_authToken=YOUR_TOKEN
@multiverse-io:registry=https://npm.pkg.github.com
```

~/.yarnrc.yml

```yaml
npmScopes:
  multiverse-io:
    npmAlwaysAuth: true
    npmAuthToken: YOUR_TOKEN
    npmRegistryServer: 'https://npm.pkg.github.com'
```

These file will allow `yarn` to access our registry

```bash
yarn add @multiverse-io/stardust
```

### Usage

There are 2 pieces to the Stardust tokens repo, [the base CSS variables](./stardust-tokens.css) and [the Tailwind present](./stardust-tailwind-preset.js).

```css
/* Some css file in your app */
@import '@multiverse-io/stardust/tokens.css';
```

And if you're using Tailwind:

```js
// tailwind.config.js
import stardustPreset from '@multiverse-io/stardust/tailwind-preset.js'

export default {
  presets: [stardustPreset],
  ...
}
```

#### Sass

There is a small amount of [Sass](https://sass-lang.com/) included in the `scss` directory for sharing of CSS primitives like breakpoints (media queries cannot container CSS variables at the time of writing, so Sass is the only option for sharing variables of that kind).

```scss
@use '@multiverse-io/stardust/scss/breakpoints' as *;

// breakpoint variables now accessible in this sass module
@media (min-width: $breakpoint-sm) {
    ...
}

// or via the builtin @mixin
@include sm-and-up {
    ...
}
```

### CI

CircleCI is our standard CI platform, and will require some setup for the `stardust` package to be available during pipelines.

Below is a command `setup-gh-packages-access` which will create an `.npmrc` & `.yarnrc.yml` in the CI container.

```yaml
commands:
  setup-gh-packages-access:
    description: 'Setup access to our Github packages'
    steps:
      - run:
          name: Add Github token to npmrc
          command: |
            echo "@multiverse-io:registry=https://npm.pkg.github.com
            //npm.pkg.github.com/:_authToken=${GITHUB_READ_PACKAGES_TOKEN}" > ~/.npmrc
      - run:
          name: Add Github token to yarnrc
          command: |
            echo "npmScopes:
              multiverse-io:  
                npmAlwaysAuth: true
                npmAuthToken: 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
                npmRegistryServer: 'https://npm.pkg.github.com\'
            " > ~/.yarnrc.yml
```

You just need to add the `setup-gh-packages-access` step to any workflows _before_ they try to install packages.

```yaml
# example
jobs:
  build_frontend:
    executor: node/default
    steps:
      - checkout
      - setup-gh-packages-access
      - node/install-packages:
          app-dir: '~/project/client'
          pkg-manager: yarn
```

And finally, a Github Access Token needs to be provided to the pipeline under the name `GITHUB_READ_PACKAGES_TOKEN`, and requires the permission for `read:packages`
