# @multiverse-io/stardust-react

## 4.9.1

### Patch Changes

- c16063e: Dropdown Items to have full width clickable

## 4.9.0

### Minor Changes

- 9ab4099: Added: Panel component system with specialized variants for different content types.
  Added: PanelCard for general content surfaces.
  Added: PanelListItems and PanelListItem for list-like content with proper spacing.
  Added: PanelTable, PanelTableHead, PanelTableBody, PanelTableRow, PanelTh, PanelTd for tabular data display.
  Design: Behavior-agnostic architecture allowing composition with other primitives like accordions.
  Docs: Comprehensive Storybook examples showing List, Table, Card, and Accordion composition patterns.

## 4.8.2

### Patch Changes

- 5804f80: Hide SVG icons from screenreaders in badge components by default.
- 36a01f8: Fixed an issue where naming inconsistencies could cause OS dependent behaviour where OSs are case sensitive.

## 4.8.1

### Patch Changes

- 33f4fb6: Move to publish from the monorepo

## 4.8.0

### Minor Changes

- e37392c: Update Choicebox component with improved styling and functionality
  - Added radio or checkbox input to clearly indicate input type
  - Updated styling for consistency with other components
  - Added support for custom choicebox content
  - Improved documentation with additional examples

## 4.7.0

### Minor Changes

- 662a317: - Added: `variant` prop with `error` state using negative tokens when checked.
  - Added: `hideLabel` for accessible labels without visual text.
  - Changed: New visual design — thinner border, improved focus ring, action tokens for checked, neutral greys for unchecked.
  - Changed: Default size standardized to 20×36 (`size="default"`); `medium` kept for compatibility but deprecated.
  - Changed: Thumb styling and motion adjusted; hover/focus ring replaces border to ensure size consistiency with colour changes.
  - Docs: Storybook updates (new Off/On/Error/VisuallyHiddenLabel stories, improved descriptions, updated Figma link).

## 4.6.0

### Minor Changes

- 8266849: Update radio input component with new styling and description prop

  - Radio input sizing normalized: both "default" and "small" now use a 20px radio control; the only difference between the two variants is the font size of the label/description text.
  - No consumer action required unless you have custom style overrides targeting the old radio input sizing/spacing. Audit and remove any redundant overrides; some may now be unnecessary or could clash with the new styles.
  - New `description` prop to render supporting text beneath the label. See docs for usage guidelines.

- 306492a: Update checkbox component with new styling and description prop
  - Checkbox sizing normalized: both "default" and "small" now use a 20px checkbox control; the only difference between the two variants is the font size of the label/description text.
  - No consumer action required unless you have custom style overrides targeting the old checkbox sizing/spacing. Audit and remove any redundant overrides; some may now be unnecessary or could clash with the new styles.
  - New `description` prop to render supporting text beneath the label. See docs for usage guidelines.

### Patch Changes

- 8eeea4c: Fix for figma code connect releases

## 4.5.4

### Patch Changes

- 1aa26ec: Add Figma Code Connect configuration for button components.

## 4.5.3

### Patch Changes

- e3f3b4f: Security: pin transitive `form-data` to 4.0.4 via Yarn `resolutions` to remediate CVE-2025-7783 (predictable multipart boundary). No runtime, API, or UI changes.

## 4.5.2

### Patch Changes

- 191d3bc: Remove scroll lock from slide-in component
- 699bb48: Add scroll lock to slide-in component
- 5893cca: Remove accordion border bottom on last item
- 89b3ecd: CROC-1402: Upgrade cross-spawn package to 7.0.6

## 4.5.1

### Patch Changes

- b096fd9: Update button padding from 24px to 16px

## 4.5.0

### Minor Changes

- 769085b: Hide environment indicator in 'ci' environment

## 4.4.0

### Minor Changes

- e943d73: - Moved custom Tailwind configuration to Stardust core

  As of [Stardust v3.6.0](https://github.com/Multiverse-io/stardust/blob/main/CHANGELOG.md#360), custom Tailwind extensions are done in the Stardust core preset. This means any custom configuration now needs to be added there instead of in this package, so that it can be consumed downstream.

## 4.3.0

### Minor Changes

- b662f2b: Stop button from having anyprop

## 4.2.2

### Patch Changes

- 9aaac72: Sort Button to use aria-label instead of sr-only div

  This helps to resolve issues with fixed width scrollable tables and the sr-only div introducing horizontal page scroll

## 4.2.1

### Patch Changes

- d03fca2: Pagination buttons disabled on totalItems=0

## 4.2.0

### Minor Changes

- 76aa62a: Readd mode switcher component to global navigation

## 4.1.3

### Patch Changes

- 969b582: Deprecation: GlobalNavigation components and hooks moved to `@multiverse-io/global-navigation`. This is to allow us to remove the dependency on our Authentication service before we move stardust to a monorepo.

## 4.1.2

### Patch Changes

- 7126155: INcrease colour contrast on success badge component

## 4.1.1

### Patch Changes

- 4852fa9: Fix dialog spacing issue and updates close button
- ad44a30: Fixed an issue where custom padding on `AccordionContent` was being applied twice by removing unnecessary inner div and properly applying default padding classes.

## 4.1.0

### Minor Changes

- 8c3008a: Added cn helper and icon helper exports for use in consuming apps.

## 4.0.1

### Patch Changes

- 97f3291: Fix issue where closing Dropdown did not focus the trigger as expected.

## 4.0.0

### Major Changes

- df30747: 💫 Stardust V4 (Major Release)

  **BREAKING CHANGES / Removals**

  - Removed deprecated `Tertiary` variant from `Button`. Use `secondary` or `text` variant instead.
  - Removed deprecated `ExternalLink` component. Use `Link` component with `isExternal={true}`.
  - Removed deprecated `NavigationHeader` component. Use components from `src/components/navigation/header.tsx` directly.
  - Removed deprecated `RadioGroup` component. Use `FormFieldset` component instead.
  - Removed deprecated `UNSTABLE__ModeSwitcher` component and props from `GlobalNavigation`. Functionality integrated differently.
  - Removed deprecated namespaced exports for `Callout`, `Dialog`, `Dropdown`, `Navigation`. Use direct non-namespaced imports.
  - Removed deprecated test files and stories associated with the removed components and variants.
  - Removed Stepper component, as not part of core components & not used across MV

  **Refactors**

  - Moved `NavigationHeaderActionsSlot` component from `Navigation` module into `GlobalNavigation` module.
  - Renamed `TableRoot` component to `Table`. Updated imports, types (`TableRootProps` -> `TableProps`), stories, and tests accordingly.
  - Removed deprecated namespaced export for `Table`. Use direct non-namespaced imports (`Table`, `TableHeader`, etc.).

  **Features**

  - Added and updated numerous SVG illustrations across Character, Decorative, Learning, and Product categories (Custom removed)

  **Chores**

  - Updated peer and dev dependencies for `@multiverse-io/stardust` to v4.0.0.
  - Updated illustration index files to reflect additions, moving & removals.
  - Updated stories and tests to reflect component renaming (`TableRoot` -> `Table`) and illustration changes.

## 3.61.0

### Minor Changes

- 49686cf: Adds 4 KSB icons (collection, knowledge, skill and behavior). Updates the competency icon visually.

## 3.60.0

### Minor Changes

- 9da7ff6: Deprecates `as` prop in Button in favor of new `asChild` prop

### Patch Changes

- 397d5ad: Fix issue that prevented switch working in server components
- ac0a226: Add documentation to the checkbox component on how to correctly integrate with react-hook-form

## 3.59.0

### Minor Changes

- a2d37df: - Added Link component
  - Deprecated ExternalLink component in favor of Link component with isExternal prop

## 3.58.0

### Minor Changes

- 58aebe2: Added card button to library

### Patch Changes

- b0c8023: Update illustrations containers

## 3.57.0

### Minor Changes

- 4806452: Adding new illustrations

## 3.56.0

### Minor Changes

- 04298f8: Added Tab component based on @radix-ui/react-tabs

### Patch Changes

- dbabce4: Disable F2 keypress functionality for environment indicator when in production environment

## 3.55.0

### Minor Changes

- d3740db: - Added `resourceType` prop to the FourOhFour component to allow customization of the error message.
- 880be41: Added Segmented Control component

## 3.54.0

### Minor Changes

- 1d138b5: **Changes**

  - Dropdown Menu updated styling

  **Removes**

  - AuthNavigation component that was unused and undocumented. GlobalNavigation was the version we shipped to consumers.

### Patch Changes

- 62e1515: replaced h6 and p tags with div and span in tooltips
- 26fe3b4: Fixed profile menu alignment in Safari by replacing place-self-end with justify-end to ensure consistent rendering across all browsers.
- 8adf5a2: fix issue where white margin would appear around toasts when a dialog is open

## 3.53.1

### Patch Changes

- 8b589cc: Fix DatePicker text color inheritance

## 3.53.0

### Minor Changes

- 06b978f: Adds new DatePicker component with time selection, excluding range selection functionality.

## 3.52.0

### Minor Changes

- e428cbc: Add SlideInFooter component

### Patch Changes

- 6ec0d05: Fixes an issue with the pagination component that prevented it being exported to consumers.

## 3.51.1

### Patch Changes

- 8d7bcef: Use modeSwitcherEnabler topnav value in the global navigation component
- a9664f0: Fix: Add background color to the Slider's header

## 3.51.0

### Minor Changes

- 2b2eaeb: Introduce SlideIn component

## 3.50.4

### Patch Changes

- fa01a5f: Aligns the error state component with the corresponding component in Figma.

## 3.50.3

### Patch Changes

- f2883aa: Enable Checkbox component to be used as a controlled component
- e3bd9a9: Fix: update pagination stories to use new table components
- 53f90c5: Add optional portal container prop to Select component

## 3.50.2

### Patch Changes

- d6f20fb: Change to use stardust's core preset directly for cn helper

## 3.50.1

### Patch Changes

- 185b861: Add css files to package files array to make sure they are included in shipped version

## 3.50.0

### Minor Changes

- 0c288fb: **Brings backwards compatible React Server Component compatibility to Stardust React.**

  How:

  - Deprecates dot notation usage of composable components.
    - e.g. `Callout.Root` -> `CalloutRoot`
    - This causes issues with RSC compilation and webpack tree shaking.
  - Removes the blanket `'use client'` directive banner in every file.
  - Removes bundling from leaf nodes to prevent 'use client' in library dependencies polluting our components.

  **Actions when upgrading:**

  This is just a minor bump as it does not contain breaking changes. That being said it is a large change to our build tooling and the way components are exported. Please, triple check your app for discrepancies when upgrading and if migrate to the non-deprecated exports when bumping your version to save future headaches.

## 3.49.0

### Minor Changes

- 5e165a0: Add header-only navigationLayout to GlobalNavigation component"
- 62bb74c: Added Pagination component

## 3.48.0

### Minor Changes

- d2cc24c: - Added support for external links in ProfileMenu component. External links display with an arrow icon and open in a new tab.
  - Upgraded `@multiverse-io/authentication-client-ts` to 0.8.0.

### Patch Changes

- 9af307c: Update vitest to remove critical vulnerability

## 3.47.1

### Patch Changes

- 23930c4: Remove the UserCircleIcon from the global-navigation component

## 3.47.0

### Minor Changes

- 7d68a7e: Bump stardust core to use new nav tokens

### Patch Changes

- 27a131b: explicit string values for auth navigation data attributes for Atlas

## 3.46.0

### Minor Changes

- b1c7f1b: Added ErrorState components and common scenarios

### Patch Changes

- 5bfe342: fixed margin for badges with thin 1 character text
- 116b3fe: Hide global nav mode switcher when there's only one mode available

## 3.45.0

### Minor Changes

- 5797ec2: Added new Apprentices illustration
- 50a692d: Make buttons use the new shadow tokens from stardust core. Fixes a bug where tertiary buttons had extra shadow.

### Patch Changes

- 6a2e5fa: Fixed image rendering in storybook examples in github pages
- 73f06e6: Bump up authentication-client-ts and use correct type for SessionResponseNav.error

## 3.44.2

### Patch Changes

- 1f7f920: Fix type error that required a href on buttons

## 3.44.1

### Patch Changes

- 8b21744: Fixed an issue where toasts were not rendering after changes to our build pipeline.

## 3.44.0

### Minor Changes

- fb84a7e: Updated Badge component with auto-styled icons, width constraints, text truncation, and improved styling.
- 6e932bd: ### Added

  - New `outline` button variant
  - Changed default font weight from `semibold` to `medium`
  - New `iconOnlyBreakpoint` prop for the `Button` component
    This allows for the button to be rendered with only an icon and no text on smaller screens
    The options are `sm` and `md`
  - Added `aria-disabled` attribute to the `Button` component when `loading` or `disabled` props are true
  - Added Buttons as Links feature
    This allows for the `Button` component to be rendered as a link when the `href` prop is provided along with a custom React component for the `as` prop

    ```tsx
    <Button href="https://multiverse.io" as="a">
      Click me
    </Button>
    // <a href="https://multiverse.io">Click me</a>

    <Button as={CustomLink} to="https://multiverse.io">
      Custom!
    </Button>
    // <CustomLink to="https://multiverse.io">Custom!</CustomLink>
    ```

  ### Deprecations

  2 deprecations have been made in this release, to bring Stardust React in line with the naming conventions in Figma.

  - Deprecated `tertiary` button, replacing with `text` variant

## 3.43.0

### Minor Changes

- dcd08ab: Adds reserved word "DEFAULT" to navigation components to allow us to hide the section heading when desired.

### Patch Changes

- a5ebd8f: Fix bug where FormFieldSet component does not pass through the rest of the props

## 3.42.1

### Patch Changes

- ef1b8b1: Fix navigation header layout in Safari

## 3.42.0

### Minor Changes

- 12191b6: Added AlertDialog Component

## 3.41.0

### Minor Changes

- b6aadf1: Add Accordion component

### Patch Changes

- 6e79bbb: Updated the package.json files key to include all output js files

## 3.40.0

### Minor Changes

- 7a5f81b: build system changes to allow treeshaking
- ca7e14c: Allow passthrough of toastProps and toasterProps in the Toaster component

### Patch Changes

- 10f2563: Removed references to the desktop breakpoint.
- 7a5f81b: added size-limit checks in ci

## 3.39.0

### Minor Changes

- 42f339e: export profile menu component

## 3.38.0

### Minor Changes

- 0d9350e: Add ability to set layout client side on page load via useGlobalNavigation hook

### Patch Changes

- 16c27cd: Add description and helperText props to the Select input component

## 3.37.1

### Patch Changes

- 46057d6: Make stardust-react allow minor updates to the stardust peer dependencies

## 3.37.0

### Minor Changes

- 4d8448b: Added close button to the environment indicator
- d8ffbf7: - Upgraded Stardust core to version [3.4.0](https://github.com/Multiverse-io/stardust/blob/main/CHANGELOG.md#340)
  - Updated all radius sizes to move away from the deprecated small, medium and large variants.
  - Navigation.MenuItem increased from `--rounded-md` to `--rounded-lg`
  - Button border radius increased from `--rounded-md` to `--rounded-lg` for medium and large buttons
  - Dropdown increased from `--rounded-md` to `--rounded-lg`
  - Callout border radius increased from `--rounded-md` to `--rounded-lg`
  - TextInput border radius increased from `--rounded-md` to `--rounded-lg` for all sizes.
  - TextArea border radius increased from `--rounded-md` to `--rounded-lg` for all sizes .
  - Select trigger border radius increased from `--rounded-md` to `--rounded-lg` for all sizes.
  - Select item border radius increased from `--rounded-sm` to `--rounded-md` for all sizes.
  - Select placeholder text now aligns to placeholder sizes from other input types, moving from `text-s` to `text-xs` in small variants.
  - Toasts border radius increased from `--rounded-md` to `--rounded-lg`
  - Tooltip border radius increased from `4px` to `--rounded-lg`
  - Added docs to skeleton to inform radius choices.
- 328eda1: - Updated underlying `Navigation.*` components to include "slots" for header customization.

  - Introduced new layout options for global navigation: floating, focus, and hidden.
  - Added support for setting an `initialNavigationLayout` for global navigation, ensuring the navigation renders in the correct layout with the correct state on the first render.
  - Provided new `useGlobalNavigation` hook for updating the global navigation layout on the client-side.
  - Introduced new components for rendering into header slots:
    - `TitlePortal`
    - `BacklinkPortal`
    - `CustomActionsPortal`

  Notes for Library Consumers

  - Changes to the `Navigation.Header` should be backwards compatible but please check compatibility with your app before release.

### Patch Changes

- fef626f: Fixed a bug where the Skeleton component was not included in the library bundle and therefore could not be used by consumers.

## 3.36.1

### Patch Changes

- 60c3488: DOL-284 - Fixed breaking profile chip on Safari

## 3.36.0

### Minor Changes

- a48529f: This PR resolves an issue with duplicate form field components caused by concurrent development.

  To address this, we’ve introduced a new FormFieldset component for better accessibility and semantic HTML. It shares most of its logic with FormField but renders a `<fieldset>` and `<legend>` instead of a `<div>` and `<label>`.

  Key Changes:

  - Added FormFieldset to handle grouped radio and checkbox inputs with appropriate HTML.
  - Updated all input components to use the new form field logic, which supports helper text and descriptions.
  - Made the label prop mandatory for all inputs, ensuring consistent and accessible use.
  - Added a hideLabel prop for those that wish to hide the label.
  - Deprecated RadioGroup in favor of the new FormFieldset, unifying styles and logic.
  - Fixed minor styling issues and addressed various small improvements.

## 3.35.1

### Patch Changes

- bca1382: js(deps[dev]) esbuild 0.19.5 -> 0.24.0
  - 0.19.5 (Oct 17th, 2024)
    - https://www.npmjs.com/package/esbuild/v/0.19.5
    - https://github.com/evanw/esbuild/tree/v0.19.5
    - https://github.com/evanw/esbuild/blob/v0.19.5/CHANGELOG.md
  - 0.24.0 (Sept 24th, 2024)
    - https://www.npmjs.com/package/esbuild/v/0.24.0
    - https://github.com/evanw/esbuild/tree/v0.24.0
    - https://github.com/evanw/esbuild/blob/v0.24.0/CHANGELOG.md

## 3.35.0

### Minor Changes

- 5f7d9b5: Export the ModeSwitcher as an unstable, deprecated component. Only for use by Cheetahs and to be removed with the Global Navigation rollout.

### Patch Changes

- 8853d8a: Made `stardust` a peer dependency as all apps have it installed anyway. This would normally be a breaking change, but given that `stardust-react` doesn't work at all unless you have `stardust`, this is really just a patch to fix a bug in the deps listing.

## 3.34.0

### Minor Changes

- 08777ed: Adds new GlobalNavigation component to fix teething issues with AuthNavigation. Deprecates AuthNavigation.

  Adds new EnvironmentIndicator component to provide a standardised way to display the current non-prod environment name across applications.

  Adds new Skeleton component to unify how we tackle loading states across applications.

  Adds framer-motion as a dependency for animations.

## 3.33.0

### Minor Changes

- 7a83e99: Added a JigsawPiece icon

## 3.32.0

### Minor Changes

- a13ef33: Renamed Emoji component to Happy, added four new emotion icons (VeryHappy, Indifferent, Sad, VerySad), and organized them in a dedicated emojis folder while preserving original functionality.

## 3.31.1

### Patch Changes

- 0d49cad: fix issue where out of sync components received new tokens before they were ready

## 3.31.0

### Minor Changes

- 421f3a8: Implemented the Select component

## 3.30.0

### Minor Changes

- c1e0935: js(deps) Move `clsx` and `class-variance-authority` to `dependencies`, as these are directly used throughout stardust-react at runtime.

## 3.29.0

### Minor Changes

- 243aca3: Add Checkbox and extend FormField component

  This version includes the Checkbox component and extends the FormField component include description and helper text as optional props - mirroring the **Label** component in Figma.

  The Checkbox comes in default and small variants and supports indeterminate state.

### Patch Changes

- 996359a: Removed a console log from the stepper context

## 3.28.1

### Patch Changes

- 2ed56f8: Fixed a hydration error in the AuthNavigation component by modifying the ModeSwitcher, resolving issues with nested buttons and ensuring correct server-side rendering and client-side hydration.
- 51f90bf: Minor styling changes on the Nav side bar components to match the figma designs

## 3.28.0

### Minor Changes

- aec3610: Add no left nav variant of AuthNavigation

  **Breaking change**:
  AuthNavigation does not expose the `PageContent` component anymore.
  This is because this components' styling needs to be dynamic based on the `navType` prop.

### Patch Changes

- c4b74f1: Styling tweaks to the Stepper component
- 5ee07d0: chore: sort components in storybook alphabetically

## 3.27.2

### Patch Changes

- 877159b: Auth nav mode switcher: toggle animation on chevron
- ca6214f: js(deps[dev]) Bump rollup 4.22.1 -> 4.22.4 via lockfile (resolves [dependabot#30](https://github.com/Multiverse-io/stardust-react/security/dependabot/30)).

## 3.27.1

### Patch Changes

- 93bbff7: make auth nav available

## 3.27.0

### Minor Changes

- a445eb6: Introducing a new AuthNavigation component as a replacement for the existing Navigation component.
  The current Navigation component is now deprecated and will be removed in a future release.
  The styling remains unchanged; the primary difference is that the new component utilizes the session response from the Auth Service to populate navigation URLs.
  Additionally, this update introduces a mode switcher functionality.
- 8547328: - js(deps[dev]) Prettier: 3.0 -> 3.3

  - Changes: https://github.com/prettier/prettier/blob/3.3.3/CHANGELOG.md
  - Release notes:
    - 3.0.0 (2023-07-05): https://prettier.io/blog/2023/07/05/3.0.0
    - 3.1.0 (2023-11-13): https://prettier.io/blog/2023/11/13/3.1.0.html
    - 3.2.0 (2024-01-12): https://prettier.io/blog/2024/01/12/3.2.0
    - 3.3.0 (2024-06-01): https://prettier.io/blog/2024/06/01/3.3.0
  - js(deps[dev]) prettier-plugin-tailwindcss 0.5.6 -> 0.6.6

    Changes: https://github.com/tailwindlabs/prettier-plugin-tailwindcss/blob/v0.6.6/CHANGELOG.md

  - js(deps[dev]) @ianvs/prettier-plugin-sort-import 4.1.1 -> 4.3.1

    Changes:

    - 4.2.0 (March 13th, 2024): https://github.com/IanVS/prettier-plugin-sort-imports/releases/tag/v4.2.0
    - 4.2.1 (March 16th, 2024): https://github.com/IanVS/prettier-plugin-sort-imports/releases/tag/v4.2.1
    - 4.3.0 (June 26th, 2024): https://github.com/IanVS/prettier-plugin-sort-imports/releases/tag/v4.3.0
    - 4.3.1 (July 12th, 2024): https://github.com/IanVS/prettier-plugin-sort-imports/releases/tag/v4.3.1

- 75dd03b: New svg images for Programme

### Patch Changes

- 10ae4ec: - js(deps[dev]) Bump vite from 5.4.3 to [5.4.6](https://github.com/vitejs/vite/blob/v5.4.6/packages/vite/CHANGELOG.md)

  Resolves:

  - https://github.com/Multiverse-io/stardust-react/security/dependabot/23: CVE-2024-45811, GHSA-9cwx-2883-4wfx
  - https://github.com/Multiverse-io/stardust-react/security/dependabot/27: CVE-2024-45812, GHSA-64vr-g452-qvp3
  - https://github.com/Multiverse-io/stardust-react/security/dependabot/28: CVE-2024-45812, GHSA-64vr-g452-qvp3
  - https://github.com/Multiverse-io/stardust-react/security/dependabot/29: CVE-2024-45811, GHSA-9cwx-2883-4wfx

- 46a28bb: Stylistic changes to AuthNavigation's mode switcher and user context menu

  Designs:

  - https://www.figma.com/design/yLTSyg7vE73pPYCbVjOi4E/Platform-app-navigation?node-id=3238-34269&m=dev&focus-id=3238-34269
  - https://www.figma.com/design/yLTSyg7vE73pPYCbVjOi4E/Platform-app-navigation?node-id=3238-34363&m=dev&focus-id=3238-34363

- 8a44cc6: Added "use client" to the dist output bundle for downstream server components to import and use in peace
- c44d45e: - js(deps[dev]) vite 5.4.6 -> 5.4.7
  - https://github.com/vitejs/vite/blob/v5.4.7/packages/vite/CHANGELOG.md
  - Additionally, fix lockfile issue via `yarn up vite --recursive`.
  - vitest + @vitest/coverage-v8 2.0.5 -> 2.1.1
    - https://github.com/vitest-dev/vitest/releases/tag/v2.1.0
    - https://github.com/vitest-dev/vitest/releases/tag/v2.1.1

## 3.26.0

### Minor Changes

- c4e1b0b: Add stepper component

## 3.25.3

### Patch Changes

- 00f8fd9: Miscellaneous security bumps via yarn `resolutions`:

  - js(deps) body-parser 1.20.3: CVE-2024-45590, GHSA-qwcr-r2fm-qrc7
  - js(deps) path-to-regexp 0.10.0: CVE-2024-45296, GHSA-9wv6-86v2-598j
  - js(deps) send 0.19.0: CVE-2024-43799, GHSA-m6fv-jmcg-4jfg
  - js(deps) serve-static 1.16.0: CVE-2024-43800, GHSA-cm22-4g7w-348p
  - js(deps) express 4.20.0: CVE-2024-43796, GHSA-qw6h-vgh9-j6wx
  - js(deps) micromatch 4.0.8: CVE-2024-4067, GHSA-952p-6rrq-rcjv

  More on yarn `resolutions`: [Docs](https://classic.yarnpkg.com/lang/en/docs/selective-version-resolutions/) | [RFC](https://github.com/yarnpkg/rfcs/blob/master/implemented/0000-selective-versions-resolutions.md) | [package.json](https://classic.yarnpkg.com/en/docs/package-json/#toc-resolutions)

## 3.25.2

### Patch Changes

- 58ab63a: Bump @multiverse-io/stardust: 3.2.0 >> 3.2.4

## 3.25.1

### Patch Changes

- 911249c: Modified the `ProfileChip` component for the count number to be able to represent bigger numbers than 10

## 3.25.0

### Minor Changes

- 6de58ea: - TypeScript: 5.3 -> 5.5
  - 5.3 (2023-11-20): https://devblogs.microsoft.com/typescript/announcing-typescript-5-3/
  - 5.4 (2024-03-06): https://devblogs.microsoft.com/typescript/announcing-typescript-5-4/
  - 5.5 (2024-06-20): https://devblogs.microsoft.com/typescript/announcing-typescript-5-5/
  - @typescript-eslint 6.10 -> 8.5
    - 6.10.0 (2024-11-23)
    - 8.5.0 (2024-09-09) https://github.com/typescript-eslint/typescript-eslint/blob/v8.5.0/CHANGELOG.md

## 3.24.0

### Minor Changes

- f147404: - Vite: 5.2 -> 5.4
  - https://github.com/vitejs/vite/blob/v5.4.3/packages/vite/CHANGELOG.md
  - @vitejs/plugin-react: 4.2.1 -> 4.3.1
    - https://github.com/vitejs/vite-plugin-react/releases/tag/v4.3.0
    - https://github.com/vitejs/vite-plugin-react/releases/tag/v4.3.1
  - vitest, @vitest/coverage-v8: 2.0.4 -> 2.0.5
    - https://github.com/vitest-dev/vitest/releases/tag/v2.0.5

## 3.23.1

### Patch Changes

- e92a86a: storybook: Fix local storybook builds (#230)

  You can run `yarn build-storybook; npx http-server ./storybook-static` again.

## 3.23.0

### Minor Changes

- 77011c8: add support for missing name in profile chip component

## 3.22.0

### Minor Changes

- 4cb44e3: Adding additional customization to the Progress component

## 3.21.0

### Minor Changes

- baa86dd: Adds the simple `Progress` component.

## 3.20.0

### Minor Changes

- 540367b: Adding initial version of LineChart, first instance of new charts
  Added dependencies:
  - recharts: "2.13.0-alpha.4"

## 3.19.1

### Patch Changes

- 292bbc1: js(deps[dev]) @changesets/cli 2.27.6 -> 2.27.7
- fcbf8ca: Fix button padding when an icon is used

## 3.19.0

### Minor Changes

- 20bd643: exports decorative illustrations

## 3.18.0

### Minor Changes

- 25bc473: new certificate illustration

## 3.17.0

### Minor Changes

- 8c07007: Make 'title' prop of <Tooltip> component optional

## 3.16.0

### Minor Changes

- a1b7a88: Storybook 8.2

  _This is an internal update only and does not affect downstream package releases, except for the possible shifting of transitive dependencies._

  Storybook, stardust-react's internal tool for building UI components in isolation, has been updated from version 8.1 to 8.2.

  Learn more about what's new in Storybook 8.2: https://storybook.js.org/blog/storybook-8-2

## 3.15.0

### Minor Changes

- e3e0cbc: Make tooltips non-interactive by default to make them work better with screen readers

  **Breaking change**. This PR makes tooltips
  [non-interactive](https://atomiks.github.io/tippyjs/v6/all-props/#interactive)
  by default. If you wish to go back to the old behaviour you can explicitly pass
  the `interactive` option to `<Tooltip>`.

### Patch Changes

- 93054e5: TextInput
  - make id required with a label #195
  - Uses a better typescript definition for TextInput to force `id` to be present when `label` prop is provided

## 3.14.0

### Minor Changes

- 2e54ec7: vitest: Upgraded to 1.6.0 -> 2.0.4
  - Release notes:
    - https://github.com/vitest-dev/vitest/releases/tag/v2.0.0
    - https://github.com/vitest-dev/vitest/releases/tag/v2.0.1
    - https://github.com/vitest-dev/vitest/releases/tag/v2.0.2
    - https://github.com/vitest-dev/vitest/releases/tag/v2.0.3
    - https://github.com/vitest-dev/vitest/releases/tag/v2.0.4
  - Migrations: https://vitest.dev/guide/migration#migrating-to-vitest-2-0

## 3.13.3

### Patch Changes

- 801f23d: remove svg hardcoded ids

## 3.13.2

### Patch Changes

- 40eb100: Bump braces from 3.0.2 to 3.0.3
- c2ef1e2: Bump express from 4.18.2 to 4.19.2
- f831bd7: Bump ws from 8.14.2 to 8.17.1

## 3.13.1

### Patch Changes

- e63e564: Adds an export for the Choicebox component

## 3.13.0

### Minor Changes

- cabb333: Adds the `<Choicebox>` component. This component adds a thing wrapper around browser native checkbox and radio button controls that is styled as a tag or card.

### Patch Changes

- 73e1655: Test release to demo changesets

## [3.12.6] - 2024-06-06

### Added

- `<Navigation.HeaderActionsSlot />` component
  This component dispatches `NavigationHeaderMounted` and `NavigationHeaderUnmounted` custom events on mount and unmount respectively
- `<Navigation.EmptyHeader />` component
  This is intended for use on pages which do not want to mount the mobile menu, but do want the navigation actions slot

## [3.12.5] - 2024-05-29

### vitest: 1.4.0 -> 1.6.0 ([#197](https://github.com/Multiverse-io/stardust-react/pull/197))

`vitest` ([npm](https://www.npmjs.com/package/vitest),
[github](https://github.com/vitest-dev/vitest)) has been updated to 1.6.0:

- https://github.com/vitest-dev/vitest/releases/tag/v1.5.0
- https://github.com/vitest-dev/vitest/releases/tag/v1.6.0

In addition, `@vitest/coverage-v8` has been upgraded from and to the same versions.

## [3.12.4] - unreleased

_Version skipped_

## [3.12.3] - 2024-06-06

- Fixed the issue that didn't allow users to navigate the dropdown menu with their arrow keys

## [3.12.2] - unreleased

_Version skipped_

## [3.12.1] - 2024-05-29

### Added

- Branded illustrations

## [3.12.0] - 2024-06-03

### Tailwind 3.4 ([#192](https://github.com/Multiverse-io/stardust-react/pull/192))

Tailwind updated from 3.3.3 to 3.4.3:

- https://tailwindcss.com/blog/tailwindcss-v3-4
- https://github.com/tailwindlabs/tailwindcss/blob/v3.4.3/CHANGELOG.md

#### Stardust 3.2.0 ([#192](https://github.com/Multiverse-io/stardust-react/pull/192))

_From [stardust#63](https://github.com/Multiverse-io/stardust/pull/63)._

Updated stardust's tailwind package to the same versions.

## [3.11.0] - 2024-06-03

### Storybook 8.1 ([#192](https://github.com/Multiverse-io/stardust-react/pull/192))

Storybook has been updated from 8.0.5 to 8.1.5:

- https://storybook.js.org/releases/8.1
- https://github.com/storybookjs/storybook/blob/v8.1.5/CHANGELOG.md

## [3.10.0] - 2024-05-29

### Removed

- The `Navigation.Header` component no longer takes a `renderLogo` prop. The positioning of the centred logo in the header has been removed in the [latest Figma designs](https://www.figma.com/design/cUyxpj0JDo21HRuI4C3VOC/Stardust?node-id=7189-80663&m=dev)

### Migration

```diff
-<Navigation.Header renderLogo={() => <Logo />} ... />
+<Navigation.Header ... />
```

## [3.9.4] - 2024-05-28

- Changed ProfileChip hashing algorithm for background color to DJB2

## [3.9.3] - 2024-05-27

- Updated edit icon to match Figma

## [3.9.2] - 2024-05-08

- Changed the focus colour for various components so it was consistent across Stardust

## [3.9.1] - 2024-05-01

- Updated the dropdown menu to bring them more in line with the current Figma designs

## [3.9.0] - 2024-04-29

- Updates `@multiverse-io/stardust` to `3.1.0` to pull in new font files that fix backtick rendering

## [3.8.0] - 2024-04-09

### Vite 5 ([#151](https://github.com/Multiverse-io/stardust-react/pull/151) and [#168](https://github.com/Multiverse-io/stardust-react/pull/168))

Vite 5 introduces new features and improvements. Learn more:

- vite 5.0:
  - https://vitejs.dev/blog/announcing-vite5
  - https://github.com/vitejs/vite/blob/v5.0.0/packages/vite/CHANGELOG.md
- vite 5.1:
  - https://vitejs.dev/blog/announcing-vite5-1
  - https://github.com/vitejs/vite/blob/v5.1.0/packages/vite/CHANGELOG.md
- vite 5.2: https://github.com/vitejs/vite/blob/v5.2.8/packages/vite/CHANGELOG.md

### vitest 1.4.0 ([#151](https://github.com/Multiverse-io/stardust-react/pull/151))

vitest is a Vite-based test tool. Learn more of vitest's improvements post-1.0:

- https://github.com/vitest-dev/vitest/releases/tag/v1.4.0
- https://github.com/vitest-dev/vitest/releases/tag/v1.3.0
- https://github.com/vitest-dev/vitest/releases/tag/v1.2.0
- https://github.com/vitest-dev/vitest/releases/tag/v1.1.0
- https://github.com/vitest-dev/vitest/releases/tag/v1.0.0

## [3.7.2] - 2024-04-09

- This version includes minor styling updates to our `Badge` component to match with Stardust Figma

## [3.7.1] - 2024-04-02

- This version adds a set of `Dialog` components to be used across React applications ([#12](https://github.com/Multiverse-io/stardust-react/issues/12))

## [3.7.0] - 2024-03-28

### Storybook 8 ([#150](https://github.com/Multiverse-io/stardust-react/pull/150))

Storybook has been updated from v7 to v8. Learn more:

- https://storybook.js.org/blog/storybook-8/
- https://github.com/storybookjs/storybook/blob/v8.0.5/CHANGELOG.md

### Storybook: Icon library search ([#163](https://github.com/Multiverse-io/stardust-react/pull/163))

Icons on storybook now include a search functionality to make it easier to find the icon you are looking for.

## [3.6.1] - 2024-03-26

- New `<Badge>` component ([#157](https://github.com/Multiverse-io/stardust-react/pull/157))

## [3.6.0] - 2024-03-21

- Bumped Stardust core to include rebranded colours and fonts ([#149](https://github.com/multiverse-io/stardust-react/pull/149))

## [3.5.2] - 2024-03-014

- Changed the logic for the postioning of the icon ([#30](https://github.com/Multiverse-io/stardust-react/issues/30))
  Fix e2e tests for safari ([#144](https://github.com/Multiverse-io/stardust-react/pull/144))

## [3.5.1] - 2024-03-07

- Added the `<Switch>` component ([#30](https://github.com/Multiverse-io/stardust-react/issues/30))
- Chore: Fix typos ([#144](https://github.com/multiverse-io/stardust-react/pull/144))

## [3.5.0] - 2024-02-28

- Added `<Table>` components [#124](https://github.com/Multiverse-io/stardust-react/pull/124)

## [3.4.6] - 2024-03-04

- Enabled users to add an icon to the`<Textarea>` component ([#136](https://github.com/Multiverse-io/stardust-react/pull/136))

## [3.4.5] - 2024-02-26

- Added `<RadioInput>` and `<RadioGroup>` components ([#133](https://github.com/Multiverse-io/stardust-react/issues/133))

## [3.4.4] - 2024-02-22

- Fix remove path clipping from `<Chat>` icon ([#135](https://github.com/Multiverse-io/stardust-react/pull/135))

## [3.4.3] - 2024-02-22

- Added new Snooze icon ([#134](https://github.com/Multiverse-io/stardust-react/pull/134))

## [3.4.2] - 2024-02-21

- New `<ProfileChip>` and `<ProfileChipStack>` components ([#126](https://github.com/Multiverse-io/stardust-react/pull/126))

## [3.4.1] - 2024-02-20

- Added a `fullWidth` prop to the `TextInput` and `Textarea` components to allow for them to take up the full width of their parent element. ([#123](https://github.com/Multiverse-io/stardust-react/issues/123))

## [3.4.0] - 2024-02-20

- Bump stardust to v2.1.0 (#130)

  stardust now uses yarn v4 (via [stardust#34](https://github.com/Multiverse-io/stardust/pull/34)).

## [3.3.0] - 2024-02-16

- Icons: Add competency icons (#129)

## [3.2.1] - 2024-02-12

- Icons: Fix export (#128)

## [3.2.0] - 2024-02-09

- Icons: Add target arrow icons (#125)

## [3.1.1] - 2024-01-31

This version opens a new tab by default when using Navigation.MenuItem with the `external` prop.

### Changes

- Default external MenuItem to open a new tab on click (but allows `target` and `rel` props to be overwritten if needed)

## [3.1.0] - 2024-01-08

This version adds a set of `Navigation` components to be used across all React apps.

### Changes

- Navigation components for applications within Multiverse. See storybook for usage documentation.
- Enabled `/assets` to serve static assets for use in storybook.

## [3.0.0] - 2024-01-19

This version changes the recommended pattern for generating the utility styles for tailwind used in our components.

> This unfortunately means that there are **more** breaking changes!

It retrospect, we could have waited longer for a 1.0 release to allow us to prototype these implementation details before setting production readiness expectations for teams! Move fast and ~~break things~~ make weekly major version updates.

### Changes

- Tailwind utils should no longer be sourced from `styles.css` in the built output.
- Applications need to include the tailwind base utilities themselves.
- The JS output should be included in the `content` key of the consuming application's tailwind config. Example in readme.
- The generated `index.css` file should be added to the consuming application to receive custom CSS for components where we need to work outside tailwind, for example to manipulate an underlying library's styles, write custom keyframes animations, or add component specific css variables. Example in readme.

## [2.0.1] - 2024-01-22

### Updated

- Add stroke and fill variants from Figma to icons ([#110](https://github.com/Multiverse-io/stardust-react/pull/110))

## [2.0.0] - 2024-01-17

This version changes the build process for the `stardust-react` package to output a single Javascript bundle.

> This unfortunately means that there are breaking changes!

### Changes

- Icons now imported from the top level of the library

  ```js
  // 🚫 current import now broken
  import { AchievementIcon } from '@multiverse-io/stardust-react/icons/Achievement';
  ```

  ```js
  // ✅ import directly
  import { AchievementIcon } from '@multiverse-io/stardust-react';
  ```

- Moved `DropdownMenu` components into a `Dropdown` namespace

  ```js
  // 🚫 previous direct imports
  import {
    DropdownMenu,
    DropdownMenuCheckboxItem,
    DropdownMenuContent,
    DropdownMenuGroup,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuPortal,
    DropdownMenuRadioGroup,
    DropdownMenuRadioItem,
    DropdownMenuSeparator,
    DropdownMenuShortcut,
    DropdownMenuSub,
    DropdownMenuSubContent,
    DropdownMenuSubTrigger,
    DropdownMenuTrigger,
  } from '@multiverse-io/stardust-react';
  ```

  ```js
  // ✅ new Dropdown namespace
  import { Dropdown } from '@multiverse-io/stardust-react';

  // Note: `DropdownMenu` component renamed to `Dropdown.Root`
  <Dropdown.Root />
  // All other components have dropped the `DropdownMenu` prefix
  <Dropdown.CheckboxItem />
  <Dropdown.Content />
  <Dropdown.Group />
  <Dropdown.Item />
  <Dropdown.Label />
  <Dropdown.Portal />
  <Dropdown.RadioGroup />
  <Dropdown.RadioItem />
  <Dropdown.Separator />
  <Dropdown.Shortcut />
  <Dropdown.Sub />
  <Dropdown.SubContent />
  <Dropdown.SubTrigger />
  <Dropdown.Trigger />
  ```

- Toast helper functions moved under a `toasts` namespace

  ```js
  // 🚫 wont work
  import {
    error,
    info,
    success,
    Toaster,
    warning,
  } from '@multiverse-io/stardust-react/toasts';
  ```

  ```js
  // ✅ use toasts namespace
  import { toasts, Toaster } from '@multiverse-io/stardust-react'
  toasts.success(...)
  toasts.warning(...)
  toasts.error(...)
  toasts.info(...)
  ```

## [1.2.6] - 2024-01-03

### Updated

- Ensure icon is aligned in `<StatusText />` ([#99](https://github.com/Multiverse-io/stardust-react/pull/99))

## [1.2.5] - 2024-01-03

### Updated

- Updated styling of `<Callout />` component ([#98](https://github.com/Multiverse-io/stardust-react/pull/98))

## [1.2.4] - 2024-01-03

### Added

- New `<Tooltip>` component ([#93](https://github.com/Multiverse-io/stardust-react/pull/93))

## [1.2.3] - 2024-01-03

### Added

- New `<Toaster>` component with helper functions for dispatching toast messages ([#89](https://github.com/Multiverse-io/stardust-react/pull/89))

## [1.2.2] - 2024-01-02

### Fixed

- SC-40255 missing types ([#91](https://github.com/Multiverse-io/stardust-react/pull/91))

## [1.2.1] - 2024-01-02

### Fixed

- Callout text color ([#90](https://github.com/Multiverse-io/stardust-react/pull/90))

## [1.2.0] - 2024-01-02

### Changes

- Consume Stardust core variable changes ([#78](https://github.com/Multiverse-io/stardust-react/pull/78))

## [1.1.6] - 2023-12-05

### Changes

- Update loading icon ([#75](https://github.com/Multiverse-io/stardust-react/pull/75))

## [1.1.5] - 2023-11-28

## [1.1.4] - 2023-11-27

### Added

- Option to pass container prop to dropdown menu ([#69](<(https://github.com/Multiverse-io/stardust-react/pull/69)>)

## [1.1.3] - 2023-11-24

## [1.1.2] - 2023-11-22

## [1.1.1] - 2023-11-17

## [1.1.0] - 2023-11-13

## [1.0.0] - 2023-11-07
